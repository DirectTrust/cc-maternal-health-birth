# DirectTrust Terminology and Artifacts Package V2

Date: 2026-10-10.

## Scope

Consolidates only the seven new CodeSystems into DTCodeSystem.json with 38 concepts. The eleven established CodeSystems, all NamingSystems, and all artifacts remain byte-for-byte unchanged. Seven separate new CodeSystem files are removed. No legacy ConceptMap is introduced.

## Identifier

Draft canonical URL: http://objects.directtrust.org/standards/terminology/CodeSystem/DTCodeSystem
Version: 1.0.0. Status: draft. An assigned OID has not been supplied and is not invented. Canonical URL and OID registration/publication must be finalized before external release.

## Families

Concepts carry a family property. This is grouping, not semantic subsumption.

| Family | Label | Count |
|---|---|---|
| provenance-activity | Provenance activities | 15 |
| provenance-agent-role | Provenance agent roles | 3 |
| transaction-type | Transaction types | 8 |
| patient-change-action | Patient change actions | 2 |
| patient-change-list-type | Patient change list types | 1 |
| failure-reason | Workflow failure reasons | 5 |
| task-input-type | Task input types | 4 |

## Code collision

The witness activity retains witness. The agent role becomes witness-agent. All other code strings, displays, definitions, and concept properties are preserved.

## ValueSets

Updated 6 ValueSets to the consolidated system, preserving their membership and external CodeSystem references. Whole-family includes use the family filter so they do not accidentally include all 38 concepts. ProvenanceActivityVS is version 3.0.0; other changed ValueSets are version 2.0.0. Unchanged ValueSets retain their versions.

## Deferred artifact reference updates

Artifacts intentionally remain unchanged. The following files still reference removed new CodeSystem URLs and require a later approved integration step. This intermediate package is not yet fully integrated for validation.

- terminology-and-artifacts/artifacts/CapabilityStatement/CapabilityStatement-DirectTrust-MaP-Payload-Testing-Tool.json: http://objects.directtrust.org/standards/terminology/CodeSystem/TransactionTypesCS
- terminology-and-artifacts/artifacts/CapabilityStatement/CapabilityStatement-DirectTrust-MaP-Payload-Testing-Tool.xml: http://objects.directtrust.org/standards/terminology/CodeSystem/TransactionTypesCS
- terminology-and-artifacts/artifacts/StructureDefinition/StructureDefinition-map-endpoint-capabilitystatement.json: http://objects.directtrust.org/standards/terminology/CodeSystem/TransactionTypesCS
- terminology-and-artifacts/artifacts/StructureDefinition/StructureDefinition-map-tx7-patient-change-list.json: http://objects.directtrust.org/standards/fhir/CodeSystem/map-patient-change-action, http://objects.directtrust.org/standards/fhir/CodeSystem/map-patient-change-list-type

Documents, CCPs and samples also require later updates. Existing CodeSystems have not been consolidated.
