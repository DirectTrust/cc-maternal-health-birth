Current release: DT_Terminology-and-Artifacts_Package_20261010_V3. See DT_PACKAGE_VERSION_3.md and terminology/OID_Assignment_Register_20261010.csv for OID assignments and updated dates. Earlier release notes are historical.

# Terminology
This repository is used to manage DirectTrust terminology artifacts for naming systems, code systems, and value sets. Updates to the current version of any artifacts in this repository cause updates to the Terminology on the DirectTrust.org website through a git action that copies updated current file versions to the DirectTrust sftp site.  

Note:  New terminology artifacts require coordination with the DirectTrust website management team to initiate the listing information to be included on the website.  They require the following information:
* Terminology artifact type, i.e. NamingSystem, CodeSystem, or ValueSet
* Terminology artifact name
* Terminology artifact link url, e.g. https://  followed by objects.directtrust.org/standards/terminology/codeSystem/ProvSuffixCS.json
* Terminology artifact description

## Naming Systems
The NamingSystems folder contains namingSystem resources created and maintained by DirectTrust.

A NamingSystem resource instance declares the existence of and describes a curated namespace that issues unique symbols within that namespace for the identification of concepts, people, devices, etc. Represents a "System" used within the Identifier and Coding data types.

## Code Systems
The CodeSystems folder contains codeSystem resources created and maintained by DirectTrust.

A CodeSystem resource instance declares the existence of and describes a code system or code system supplement and its key properties, and optionally define a part or all of its content.

## Value Sets
The ValueSets folder contains valueSet resources created and maintained by DirectTrust.

A ValueSet resource instance specifies a set of codes drawn from one or more code systems, intended for use in a particular context. ValueSets are used in technical specifications to link a set of codes defined in specific CodeSystems to that code-set's intended use in a coded element.

## MaP conformance artifacts

In addition to terminology resources, this package contains MaP FHIR R4 conformance artifacts under
`artifacts/StructureDefinition/` and endpoint-specific examples under `artifacts/CapabilityStatement/`.
See `DT_PACKAGE_VERSION_2.md` for the current release and `VERSION_1.3.0.md` for the MaP additions.

## MAP intended recipient

`artifacts/StructureDefinition/StructureDefinition-dt-intendedRecipient.json` defines the DirectTrust List extension supporting Organization, PractitionerRole, or Practitioner. Practitioner without organization and role context is STRONGLY NOT RECOMMENDED. See `VERSION_1.7.0.md` for the scope, canonical URL, and publication status.

## Shared MAP failure reasons

`terminology/CodeSystem/MAPFailureReasonCS.json` and `terminology/ValueSet/MAPFailureReasonVS.json` define the initial five shared workflow failure reasons for TX8. See `VERSION_1.10.0.md` for canonical identifiers, intended extensible binding, publication status, and remaining integration work.

## Common MAP Task inputs

`terminology/CodeSystem/TaskInputCS.json` and `terminology/ValueSet/TaskInputVS.json` define the four common Task input type codes already used by the MAP prototypes. Context input types remain in their established Context terminology. See `VERSION_1.11.0.md` for canonical URLs, value semantics, draft publication status and integration notes.

## Revised Provenance activities

See `VERSION_1.13.0.md` for the verb-based vocabulary, removal of unpublished draft activity codes, and package-level TX8 disposition.

## DirectTrust consolidated terminology package baseline

This is DT_Terminology-and-Artifacts_Package_20261010_V1. It establishes a new package series from terminology-and-artifacts_20261010_V1_13. Existing directory structure and artifacts are preserved. CodeSystem consolidation has not yet been performed. See DT_PACKAGE_VERSION_1.md.

## V2 consolidation of new terminology

See DT_PACKAGE_VERSION_2.md for the draft common CodeSystem, seven families, ValueSet updates, witness-agent collision resolution, and deferred artifact references. Existing CodeSystems, NamingSystems, and artifacts remain unchanged.
