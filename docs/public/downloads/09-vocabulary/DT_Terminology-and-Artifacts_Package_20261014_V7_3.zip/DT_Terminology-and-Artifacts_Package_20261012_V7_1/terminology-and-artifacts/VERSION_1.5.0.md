# Terminology Package 1.5.0

Date: October 4, 2026
Baseline: terminology-and-artifacts_20261004_V1_4.zip

## Maternal Health Birth Notification format code

Added `urn:dt-org:dsm:map:cda:maternal-health-birth-notification:1.0` to DTFormatCodeCS and DTFormatCodeVS.

- Display: MAP Maternal Health Birth Notification CDA — Version 1.0
- Code system: `http://objects.directtrust.org/standards/terminology/CodeSystem/DTFormatCodeCS`
- DTFormatCodeCS version: 1.1.0
- DTFormatCodeVS version: 1.1.0

The code is assigned for project use. The maternal Birth Notification CDA document template, newborn section LOINC code and entry codes/templates remain open. The format code is distinct from document type code `DT20260913-1` in DTTemporaryCodeCS; that document type still requires a LOINC assignment. Existing temporary-code concepts were preserved. No publication to the DirectTrust website or repository is performed by creating this package.

## Preservation and validation

All previous archive members are retained. Only DTFormatCodeCS.json, DTFormatCodeVS.json and README.md were changed; this release note was added. All previous concepts remain present, the format-code count is six, the new concept appears once in both resources, and JSON parsing and ZIP integrity checks passed.
