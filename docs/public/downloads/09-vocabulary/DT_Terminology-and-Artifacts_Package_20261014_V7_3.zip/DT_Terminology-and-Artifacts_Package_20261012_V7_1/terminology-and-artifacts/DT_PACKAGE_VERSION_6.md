# DirectTrust Terminology and Artifacts Package V6

Updated 2026-10-12 from the supplied V5.1 package.

## Corrections

- HispIdVS: correct include.system to the exact HispIdCS canonical; add its first explicit version 1.0.0.
- IalCodeVS: correct include.system to the exact IalCodeCS canonical; version 1.0.1.
- ialCodeEX: correct the IalCodeVS binding and align differential slice IDs with IalCode; version 1.0.1. Existing extension and child URLs are preserved.
- map-endpoint-capabilitystatement: use DTCodeSystem in the TX8 bidirectional invariant; version 1.0.3.
- map-tx7-patient-change-list: use DTCodeSystem in classification, fixed action system, and all affected invariants; version 0.2.1. Code strings and the action ValueSet canonical are preserved.
- map-intended-workflow: clarify advertised initial endpoint discovery versus the endpoint set carried in the originating Task; version 1.0.2. No cardinality, binding, or wire-format change.
- Included CapabilityStatement JSON and XML: use DTCodeSystem for transaction codings and align version 1.0.2, date and narrative date. Repair XML extension URL attributes and inherited/resource element ordering without changing capability declarations.

All existing canonical URLs, resource IDs, OID assignments, concepts, and unchanged files are preserved. The IAL internal differential element IDs change only to match the existing slice name; wire URLs remain unchanged.

## Verification and remaining work

ZIP integrity, JSON/XML parsing, repaired canonical dependencies, slice ID consistency, terminology membership, retired-system removal in the repaired definitions, semantic positive/negative cases, and JSON/XML example agreement checked. Full FHIR validator execution and snapshot generation were not performed.

Patient-resolution/new-chart policy encoding, multiple advertised endpoint cardinality, intended-workflow vocabulary redesign, TX7 pending XD mapping, and missing MAP snapshot/packaging profiles remain separate design work. This package does not add new policy codes or extensions.
