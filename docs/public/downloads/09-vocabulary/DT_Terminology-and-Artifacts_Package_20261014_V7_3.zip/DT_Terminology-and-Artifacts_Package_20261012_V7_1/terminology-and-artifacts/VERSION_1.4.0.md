# Terminology and Artifacts Package — Version 1.4.0

Release date: 2026-10-04

## Changes

Updated DTContextTypeCodeVS to version 1.2.0. Retained all five existing DirectTrust concepts and added five IHE identifier types under a separate compose.include with system urn:ietf:rfc:3986:

- urn:ihe:iti:xds:2013:accession — Accession number
- urn:ihe:iti:xds:2013:referral — Referral number
- urn:ihe:iti:xds:2013:order — Order number
- urn:ihe:iti:xds:2016:studyInstanceUID — DICOM Study Instance UID
- urn:ihe:iti:xds:2015:encounterId — Encounter identifier

The complete URN is the code. These external concepts were not added to the DirectTrust CodeSystem. Study Instance UID uses 2016 and encounter identifier uses 2015, as specified by IHE.

## Sources

- IHE ITI TF Volume 3, Table 4.2.3.1.7-2 (CXi identifier type definitions): https://profiles.ihe.net/ITI/TF/Volume3/ch-4.2.html#4.2.3.1.7
- IHE ITI TF Volume 2, Appendix Z, Section Z.9.1.2 (FHIR mapping): https://profiles.ihe.net/ITI/TF/Volume2/ch-Z.html#Z.9.1.2

## Validation

All JSON artifacts parse successfully. The ZIP passes its integrity check. Existing package entries are preserved; only DTContextTypeCodeVS.json and the README release pointer were modified, and this release note was added. Formal HL7 FHIR Validator / IG Publisher validation was not performed.
