# DirectTrust Terminology and Artifacts Package V5

Last updated: 2026-10-12.

Expands ProvenanceAgentTypeVS to version 3.0.0 with fifteen participation types: Enterer, Performer, Author, Editor, Verifier, Legal Authenticator, Attester, Informant, Custodian, Assembler, Transformer, Composer, Witness, Recorder, and Notary. External concepts retain their HL7 code system identities. Existing canonical URLs and OID assignments remain unchanged.

ProvenanceActivityVS remains version 3.0.0 with twenty-one activities. DTContextTypeCodeVS remains version 1.2.0; its current coverage is accepted. All other existing entries are unchanged.
