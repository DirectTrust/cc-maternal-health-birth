# Version 1.11.0 — Common MAP Task input terminology (2026-10-06)

Adds `terminology/CodeSystem/TaskInputCS.json` and `terminology/ValueSet/TaskInputVS.json`, each artifact version 0.1.0 with draft publication status. Every baseline ZIP entry is preserved byte for byte except README.md, which identifies this release and the additions.

## Canonical identifiers
- CodeSystem: http://objects.directtrust.org/standards/terminology/CodeSystem/TaskInputCS
- ValueSet: http://objects.directtrust.org/standards/terminology/ValueSet/TaskInputVS

The CodeSystem canonical and exact code spellings match the existing ADT, TX3, TX5, TX7_A08, TX7_noA08 and shared TX8 generators. Existing sample Coding.system values therefore require no rename.

## Concepts and expected values
| Task.input.type code | Expected Task.input value | Meaning |
| --- | --- | --- |
| use-case | valueCoding | Declared use case, using its own code system (for example ServDescCS) |
| information-recipient | valueReference | Intended recipient resource, using the MAP recipient rules |
| request-workflow-status | valueBoolean | Requests successful Payload Receipt reporting; false does not suppress required failure reporting |
| workflow-status-update-endpoint | valueReference | Endpoint resource for workflow status reporting |

Value types in this table document existing usage; this terminology release does not create a Task profile or enforce resource constraints. The consumer specification/profile should declare the binding and cardinalities. The intended common-input binding is extensible; the ValueSet itself has no binding-strength property.

## Context inputs remain distinct
A Context input can use its Context type as Task.input.type and also use that type in Task.input.valueIdentifier.type. Perinatal continues to use the established DTContextTypeCodeCS concept. Do not replace that code with a generic TaskInputCS code. TransactionTypesCS, ProvenanceActivityCS, MAPFailureReasonCS/VS and existing extension/profile artifacts remain unchanged.

## Publication and remaining work
The draft artifacts are present in this package; public availability at their canonical URLs is not asserted. Coordinate their publication using the README process. Consuming documentation should identify this common input ValueSet and describe its binding alongside the separate Context input requirements. Prototype reports that still say TaskInputCS is absent should be refreshed in the next prototype releases. This package update does not fix the ADT CCP timing, metadata extraction, identifier preservation or report bugs.

## Validation
- JSON parse and official FHIR R4 schema validation for both new resources.
- Four unique case-sensitive concepts; count matches concept list.
- Exact CodeSystem canonical matches current consumer references; ValueSet membership and display values match the CodeSystem.
- ZIP integrity and byte preservation of every baseline entry except README.md.
- Existing JSON resources still parse.

This is not terminology server publication or full HL7 Validator/profile validation.
