#!/usr/bin/env python3
"""
Syncs repository content to the SFTP site.

Two sync trees are defined:

  terminology/  ->  /kwickenhauser/objects/standards/terminology
  artifacts/    ->  /kwickenhauser/objects/standards/artifacts

Each repo subfolder is mirrored to an identically named SFTP subfolder
(exact, case-sensitive match).

Rules:
  - New files in repo   -> upload to SFTP
  - Modified files      -> overwrite on SFTP (detected via MD5 comparison)
  - Files removed from repo (or present only on SFTP) -> delete from SFTP
  - Remote subfolders within a managed tree with no repo counterpart -> deleted (recursive)
  - Only terminology/ and artifacts/ are synced; everything else under /kwickenhauser/objects/standards/ is untouched
"""

import hashlib
import os
import stat
import sys
from dataclasses import dataclass
from pathlib import Path

import paramiko

SFTP_HOST = os.environ["SFTP_HOST"]
SFTP_USERNAME = os.environ["SFTP_USERNAME"]
SFTP_PASSWORD = os.environ["SFTP_PASSWORD"]
SFTP_PORT = int(os.environ.get("SFTP_PORT", "22"))

# Repo root is two levels above this script (.github/scripts/sync_sftp.py)
REPO_ROOT = Path(__file__).resolve().parent.parent.parent


@dataclass
class SyncTree:
    local_root: Path
    sftp_base: str


SYNC_TREES = [
    SyncTree(
        local_root=REPO_ROOT / "terminology",
        sftp_base="/kwickenhauser/objects/standards/terminology",
    ),
    SyncTree(
        local_root=REPO_ROOT / "artifacts",
        sftp_base="/kwickenhauser/objects/standards/artifacts",
    ),
]


def md5_local(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_remote(sftp: paramiko.SFTPClient, remote_path: str) -> str:
    h = hashlib.md5()
    with sftp.open(remote_path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def remote_dir_exists(sftp: paramiko.SFTPClient, path: str) -> bool:
    try:
        result = sftp.stat(path)
        return stat.S_ISDIR(result.st_mode)
    except FileNotFoundError:
        return False


def list_remote_files(sftp: paramiko.SFTPClient, remote_dir: str) -> dict[str, str]:
    """Returns {filename: full_remote_path} for all non-directory entries."""
    try:
        entries = sftp.listdir_attr(remote_dir)
    except FileNotFoundError:
        return {}
    return {
        e.filename: f"{remote_dir}/{e.filename}"
        for e in entries
        if not stat.S_ISDIR(e.st_mode)
    }


def remove_remote_dir(sftp: paramiko.SFTPClient, remote_dir: str) -> None:
    """Recursively delete a remote directory and all its contents."""
    for entry in sftp.listdir_attr(remote_dir):
        path = f"{remote_dir}/{entry.filename}"
        if stat.S_ISDIR(entry.st_mode):
            remove_remote_dir(sftp, path)
        else:
            sftp.remove(path)
    sftp.rmdir(remote_dir)


def sync_folder(sftp: paramiko.SFTPClient, local_dir: Path, remote_dir: str) -> None:
    """Sync all files in local_dir to remote_dir, mirroring additions, modifications, and deletions."""
    print(f"\nSyncing: {local_dir.name}  ->  {remote_dir}")

    if not remote_dir_exists(sftp, remote_dir):
        print(f"  Creating remote directory: {remote_dir}")
        sftp.mkdir(remote_dir)

    remote_files = list_remote_files(sftp, remote_dir)  # {name: path}
    local_files = {f.name: f for f in local_dir.iterdir() if f.is_file()}

    # Upload new or modified files
    for name, local_path in local_files.items():
        remote_path = f"{remote_dir}/{name}"

        if name not in remote_files:
            print(f"  [NEW]      {name}")
            sftp.put(str(local_path), remote_path)
        else:
            local_hash = md5_local(local_path)
            remote_hash = md5_remote(sftp, remote_files[name])
            if local_hash != remote_hash:
                print(f"  [MODIFIED] {name}")
                sftp.put(str(local_path), remote_path)
            else:
                print(f"  [UNCHANGED] {name}")

    # Delete remote files that no longer exist in the repo (exact name match)
    for name, remote_path in remote_files.items():
        if name not in local_files:
            print(f"  [DELETED]  {name}")
            sftp.remove(remote_path)


def sync_tree(sftp: paramiko.SFTPClient, tree: SyncTree) -> int:
    """Sync all subfolders of tree.local_root to tree.sftp_base. Returns error count."""
    print(f"\n{'=' * 60}")
    print(f"Syncing tree: {tree.local_root.name}  ->  {tree.sftp_base}")
    print(f"{'=' * 60}")

    if not tree.local_root.is_dir():
        print(f"WARNING: Local root {tree.local_root} does not exist, skipping.")
        return 0

    errors = 0
    local_folders = sorted(d for d in tree.local_root.iterdir() if d.is_dir())

    if not local_folders:
        print(f"No subfolders found in {tree.local_root}.")
        return 0

    local_folder_names = {d.name for d in local_folders}
    for local_dir in local_folders:
        remote_dir = f"{tree.sftp_base}/{local_dir.name}"
        try:
            sync_folder(sftp, local_dir, remote_dir)
        except Exception as exc:
            print(f"ERROR syncing {local_dir.name}: {exc}", file=sys.stderr)
            errors += 1

    # Delete remote folders that have no repo counterpart within this tree
    try:
        remote_entries = sftp.listdir_attr(tree.sftp_base)
        for entry in remote_entries:
            if stat.S_ISDIR(entry.st_mode) and entry.filename not in local_folder_names:
                remote_dir = f"{tree.sftp_base}/{entry.filename}"
                print(f"\n  [DELETED FOLDER] {remote_dir}")
                try:
                    remove_remote_dir(sftp, remote_dir)
                except Exception as exc:
                    print(f"ERROR deleting remote folder {remote_dir}: {exc}", file=sys.stderr)
                    errors += 1
    except Exception as exc:
        print(f"WARNING: Could not enumerate remote base directory {tree.sftp_base}: {exc}")

    return errors


def main() -> int:
    print(f"Connecting to {SFTP_HOST}:{SFTP_PORT} ...")
    transport = paramiko.Transport((SFTP_HOST, SFTP_PORT))
    try:
        transport.connect(username=SFTP_USERNAME, password=SFTP_PASSWORD)
    except Exception as exc:
        print(f"ERROR: SFTP connection failed: {exc}", file=sys.stderr)
        return 1

    sftp = paramiko.SFTPClient.from_transport(transport)
    total_errors = 0

    try:
        for tree in SYNC_TREES:
            total_errors += sync_tree(sftp, tree)
    finally:
        sftp.close()
        transport.close()

    if total_errors:
        print(f"\nCompleted with {total_errors} error(s).", file=sys.stderr)
        return 1

    print("\nSync complete.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
