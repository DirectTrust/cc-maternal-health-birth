# Version 1.10.0 — Shared MAP failure reasons (2026-10-06)

Adds MAPFailureReasonCS.json and MAPFailureReasonVS.json, each artifact version 0.1.0, with draft publication status. All baseline files are preserved byte for byte except README.md, which now identifies this release and describes the additions.

## Canonical identifiers
- CodeSystem: http://objects.directtrust.org/standards/fhir/CodeSystem/map-failure-reason
- ValueSet: http://objects.directtrust.org/standards/fhir/ValueSet/map-failure-reason

## Initial concepts
- sender-not-authorized
- unsupported-use-case
- payload-not-processable
- patient-not-found
- context-not-found

The ValueSet explicitly includes these five concepts. They describe failure to perform the requested workflow activity, not transport delivery failure. Optional Context absence is not itself a failure; unknown patient handling depends on the transaction's registration rules.

## Intended use and remaining integration
The consuming MAP specification/profile should declare an extensible binding to this ValueSet. No binding strength is encoded as a ValueSet property. Subsequent generator and documentation updates must use the CodeSystem canonical in Coding.system and the exact code spelling, with explanatory human-readable failure details. Existing generators, TX definitions and their references are not changed by this package update. No new Task profile or Task.output.type code is introduced.

The canonical URLs follow the package's existing MAP FHIR conventions. Draft artifacts require publication coordination described in README.md; inclusion here does not assert that the URLs are already published.

## Validation
All non-repository JSON resources parse successfully. New resource identifiers, unique case-sensitive concept codes, concept count, ValueSet membership and canonical linkage were checked. ZIP integrity and preservation of every baseline file except README.md were verified. Full FHIR terminology server or HL7 Validator validation has not been performed.
