# Terminology and Artifacts Package — Version 1.3.0

Release date: 2026-10-02

## Changes in this version

This release consolidates the MaP transaction, provenance, and endpoint-capability artifacts developed for
`cc-maternal-health-birth`.

### New terminology artifacts

- `TransactionTypesCS` and extensional `TransactionTypesVS`
  - Defines the eight canonical MaP transaction codes.
- `ProvenanceAgentTypeCS` and `ProvenanceAgentTypeVS`
  - Adds DirectTrust provenance participation types and reuses the FHIR `performer` concept where applicable.
- `ProvenanceActivityCS` and extensional `ProvenanceActivityVS`
  - Defines DirectTrust provenance activities and reuses appropriate external lifecycle/data-operation codes.

### Existing terminology retained

- `MetadataTypeCS` and `MetadataTypeVS` are retained unchanged from Version 1.2.0.
  The ValueSet already explicitly enumerates the DirectTrust metadata-type codes.

### New MaP conformance artifacts

Added the MaP Endpoint CapabilityStatement profile and supporting extensions under
`artifacts/StructureDefinition/`:

- `map-endpoint-capabilitystatement`
- `map-supported-usecase`
- `map-supported-transaction`
- `map-metadata-packaging`
- `map-correlated-response-same-as-originating`
- `map-identifier-capability`
- `map-terminology-capability`
- `map-intended-workflow`

The endpoint CapabilityStatement profile is version 1.0.2 and includes the MaP invariant that
`send-workflow-status` (TX8) is declared with both Send and Receive support.

### Example endpoint capability

Added JSON and XML representations of the endpoint-specific CapabilityStatement for the
DirectTrust Payload Testing Tool at `mapFramework@Direct3.DirectTrust.org`.

The example:
- declares all eight canonical MaP transactions using `TransactionTypesCS`;
- declares Send and Receive independently;
- declares TX8 Send=true and Receive=true;
- uses the existing `MetadataTypeCS` codes for XD and FHIR metadata;
- declares XD and FHIR metadata support in both directions, with FHIR preferred; and
- declares correlated TX8 responses to use the same metadata representation as the originating transaction.

## Validation status

All JSON artifacts in this package were parsed successfully, the XML CapabilityStatement was parsed successfully,
and ZIP integrity was checked during package assembly. Formal validation with the HL7 FHIR Validator / IG Publisher
has not yet been performed.
