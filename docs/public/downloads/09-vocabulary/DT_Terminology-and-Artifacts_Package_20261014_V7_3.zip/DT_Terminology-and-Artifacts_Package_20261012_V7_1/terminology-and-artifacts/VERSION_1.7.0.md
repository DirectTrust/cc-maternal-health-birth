# Terminology and Artifacts 1.7.0

Date: 2026-10-05
Baseline: supplied terminology-and-artifacts_20261004_V1_6.zip archive.

## New DirectTrust intended recipient extension

- File: artifacts/StructureDefinition/StructureDefinition-dt-intendedRecipient.json
- Canonical: http://objects.directtrust.org/standards/fhir/StructureDefinition/dt-intendedRecipient
- FHIR version: R4 4.0.1
- Context: List
- Value: exactly one Reference per extension occurrence; target types Organization, PractitionerRole, or Practitioner.
- Extension status/version: draft / 0.1.0. This archive adds the definition; external publication is a separate step.

Use this DirectTrust extension in MAP List metadata in place of ihe-intendedRecipient when applying the agreed MAP recipient pattern. PractitionerRole retains the receiving provider's organization and role relationship. A Practitioner reference with no relationship to an Organization and the practitioner's role is STRONGLY NOT RECOMMENDED. Organization references remain supported for organization-level recipients.

The Workflow Activity Task Information Recipient input should identify the same recipient as the List extension. A transport Endpoint is not the Information Recipient. A PractitionerRole may reference the selected Direct Endpoint, its Practitioner, and its Organization, all carried as supporting Bundle entries.

This is a FHIR StructureDefinition, not a terminology code; no CodeSystem or ValueSet is added for its canonical name. No existing terminology or other conformance definitions were changed. The pre-existing README cited 1.5.0 although the supplied archive was labeled V1_6; this release does not invent missing historical 1.6.0 release notes.

## Validation and remaining work

The new StructureDefinition passes the official FHIR R4 JSON schema structural check. Its fixed URL equals its canonical URL and its target types match the agreed decision. TX3 prototype V6 uses this canonical with a PractitionerRole target; paired simulated TX8 packages may identify an Organization.

Include this resource in the normal DirectTrust artifact publication process. Update Appendix D's diagram labels, recipient crosswalk, and explanatory table to use dt-intendedRecipient instead of ihe-intendedRecipient. Remaining source-patient/context/purpose extension definitions, TaskInput vocabulary, and final MAP profiles are outside this focused package update.
