# Terminology and Artifacts Package — Version 1.1.0

Release date: 2026-09-26

## Change in this version
Added `urn:dt-org:dsm:map:2025:perinatal` — **The context type is a perinatal episode**.

Definition: A longitudinal context representing continuity of maternal care associated with a pregnancy, spanning prenatal care, labor and delivery, and postpartum care through clinical closure of the episode.

Updated:
- `terminology/CodeSystem/DTContextTypeCodeCS.json` — version 1.1.0
- `terminology/ValueSet/DTContextTypeCodeVS.json` — version 1.1.0

The existing `pregnancy` code is retained for backward compatibility.
