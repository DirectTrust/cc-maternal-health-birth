# Version 1.8.0 — TX7 Patient Change List (2026-10-05)

Adds one draft FHIR R4 resource profile: map-tx7-patient-change-list.
Adds the required Add/Remove CodeSystem and ValueSet and a fixed List purpose CodeSystem.
No Patient or Bundle profiles and no new custom extensions are introduced.

## External dependency
Use the HL7 targetElement extension at http://hl7.org/fhir/StructureDefinition/targetElement, from the R4-compatible HL7 FHIR Extensions Pack (5.3.0). A publishing/validation project must load its R4-compatible package definition; the R5 package must not be treated as an R4 dependency. The canonical is reused, not copied or replaced.

## Profile rules
List.mode is changes. Each entry has exactly one action coding, an explicit deleted boolean and one targetElement extension on its Patient reference. Remove requires deleted=true; Add requires deleted=false. At least one change is required. Each target resolves to an actual populated element in a Patient carrier in the primary Collection Bundle. Primitive elements use Element.id (JSON primitive companion metadata, XML id attribute); complex elements use their element id. No #element fragment is appended to Reference.reference.

Targets are limited to names, patient identifiers, telephone contact data, addresses, administrative sex, birth date/birth details represented in base R4 multipleBirth[x], and death information. Coverage/member IDs and account IDs are excluded even when placed in Patient.identifier. Extensions are not change targets in this draft. Broader birth/gender details would require a subsequent explicit scope decision.

Removed values are preserved in a Patient carrier for element targeting; they are not deleted from the transmitted evidence. The list describes field changes, not deletion of a Patient resource. A correction uses Remove/Add entries processed together. Bundle assembly, carrier identity, correction grouping, recipient selection, mismatch handling and human-readable coverage will be specified in the TX7 Definition. This profile alone is not a complete executable update protocol.

## Validation and status
Draft differential only, consistent with the existing artifact authoring approach. JSON parsing, structural checks, terminology links, cardinality and constraint consistency, and exact byte preservation of all baseline files were checked. Full HL7 Validator snapshot generation and conformance validation have not been performed. Publishing and the TX7 documentation remain subsequent work.
