# Terminology and Artifacts Package — Version 1.2.0

Release date: 2026-09-27

## Changes in this version

Added two temporary terminology concepts needed for MaP metadata classification:

- `DT20260927-1` — **Hospital Registration Notification**
- `DT20260927-2` — **Patient Update**

These concepts support the current MaP metadata design in which the principal DocumentEntry `typeCode`
is also used as `SubmissionSet.contentTypeCode`.

Updated:
- `terminology/CodeSystem/DTTemporaryCodeCS.json` — version 1.1.0; count increased from 4 to 6
- `terminology/ValueSet/DTTemporaryCodeVS.json` — version 1.1.0

The previously defined temporary codes are retained unchanged.
