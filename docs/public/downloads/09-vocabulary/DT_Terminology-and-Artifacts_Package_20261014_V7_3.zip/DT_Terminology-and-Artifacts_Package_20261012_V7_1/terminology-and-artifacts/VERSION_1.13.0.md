# Terminology and Artifacts 1.13.0

Date: 2026-10-10.

ProvenanceActivityCS and ProvenanceActivityVS are version 2.0.1. The CodeSystem contains only the fifteen agreed DirectTrust activities: receive, register, replace, retrieve, seal, store, import, append, sign, deliver, assemble, accept, reject, notarize, witness.

The nineteen superseded unpublished activity codes have been removed entirely, together with the deprecation property and their migration table. No legacy mappings are provided for these development-only codes.

The ValueSet still contains twenty-one activities: the fifteen DirectTrust verbs and six external codes (CREATE, NULLIFY, disclose, amend, transform, transmit). External systems, codes and source displays are unchanged.

For MAP TX8, accept or reject targets the entire originating SubmissionSet/List; sufficient receipt is implied. Acceptance does not establish downstream service fulfillment. TX8 Task.status retains completed for acceptance and failed for rejection. No TX8 is generated for TX8.

This package revision does not consolidate other CodeSystems or update CCPs, documentation, or samples. All unrelated artifacts are preserved. Canonical server publication is a separate step.
