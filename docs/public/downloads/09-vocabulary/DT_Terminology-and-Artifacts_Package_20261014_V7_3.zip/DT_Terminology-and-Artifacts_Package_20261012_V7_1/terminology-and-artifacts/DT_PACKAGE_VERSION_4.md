# DirectTrust Terminology and Artifacts Package V4

Last updated: 2026-10-11.

Adds DT-20261011-1 (Provenance Information) to the established DTTemporaryCodeCS and DTTemporaryCodeVS. The code classifies a FHIR Collection Bundle containing one or more Provenance resources, carried as an information object in a structured payload. It is not a Provenance activity code.

The two updated resources are version 1.2.0 and dated 2026-10-11. Existing canonical URLs and OID assignments remain unchanged. This temporary code belongs to the existing temporary-code system; it is not duplicated in the consolidated DirectTrust CodeSystem. All other existing package entries, including artifacts and NamingSystems, are unchanged.
