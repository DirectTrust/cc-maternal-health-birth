# DirectTrust Terminology and Artifacts Package V7

Built October 12, 2026 from the supplied V6 package.

Added artifacts/StructureDefinition/StructureDefinition-map-tx8-package-identification-snapshot.json, version 0.1.0, status draft, FHIR R4 4.0.1. This profile describes the minimal originating-package List identification snapshot carried by TX8, including its preserved identifier/source/time/purpose and omitted original membership. Its canonical URL is http://objects.directtrust.org/standards/fhir/StructureDefinition/map-tx8-package-identification-snapshot.

All V6 members and their bytes are retained; only the enclosing package folder name changes to V7. No existing canonical URL, resource ID, OID, CodeSystem, ValueSet or artifact definition was altered.

Validation: ZIP integrity and JSON parsing verified; new profile matches the separately supplied draft byte for byte. Full FHIR profile validation and snapshot generation remain outstanding. The V6 release notes are retained as history.
