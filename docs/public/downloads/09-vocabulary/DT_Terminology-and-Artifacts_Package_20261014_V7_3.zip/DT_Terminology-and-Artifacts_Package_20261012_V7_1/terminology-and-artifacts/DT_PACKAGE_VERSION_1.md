# DirectTrust Terminology and Artifacts Package V1

Date: 2026-10-10

Baseline: terminology-and-artifacts_20261010_V1_13.zip.

This release starts the new DirectTrust package series in preparation for staged CodeSystem consolidation. The existing terminology-and-artifacts root and all existing directory paths are retained. Every file under artifacts/ is byte-for-byte unchanged. Terminology resources, including canonical identifiers and versions, are unchanged in this baseline. Existing historical release notes remain available.

The planned consolidation, new common CodeSystem identifier, concept-family organization, and legacy ConceptMap are not implemented in this release.
