# Terminology and Artifacts 1.12.0

Introduced the fifteen DirectTrust base-verb Provenance activities and retained six external activities. This development release is superseded by VERSION_1.13.0.md, which removes the unpublished legacy activity codes and their deprecation and migration guidance.
