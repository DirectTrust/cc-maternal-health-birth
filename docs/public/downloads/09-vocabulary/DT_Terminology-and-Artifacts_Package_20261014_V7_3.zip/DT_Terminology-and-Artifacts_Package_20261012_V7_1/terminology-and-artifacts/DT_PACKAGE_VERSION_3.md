# DirectTrust Terminology and Artifacts Package V3

Last updated: 2026-10-10.

## OID allocations

At the package owner's direction, this package uses 1.3.6.1.4.1.41179.4 as the standards vocabulary and artifacts root. Availability of this arc has not been independently confirmed against DirectTrust's internal allocation register. These are owner-directed allocations, not a claim of external registration.

- CodeSystems: 1.3.6.1.4.1.41179.4.1.x
- Consolidated DirectTrust CodeSystem: 1.3.6.1.4.1.41179.4.1.1
- ValueSets: 1.3.6.1.4.1.41179.4.2.x
- Other artifacts: 1.3.6.1.4.1.41179.4.3.x reserved; no assignments made in this version.

Assigned OIDs to all 12 CodeSystems (11 established and one consolidated) and all 19 ValueSets. Each resource carries an identifier with system urn:ietf:rfc:3986 and value urn:oid:<OID>. All vocabulary resource dates are 2026-10-10. See terminology/OID_Assignment_Register_20261010.csv for the authoritative allocation table. Keep existing allocations stable when adding resources; do not regenerate numbers by sorting a future inventory.

Canonical URLs, vocabulary versions, codes, displays, definitions, ValueSet membership and external terminology references are unchanged from V2. Existing CodeSystems remain separate. NamingSystems and artifacts remain byte-for-byte unchanged.

This supersedes V2's statement that the consolidated CodeSystem has no OID. Its canonical URL and draft status remain unchanged. The four deferred artifact reference updates listed in DT_PACKAGE_VERSION_2.md remain outstanding; this release assigns identifiers only and does not resolve those references.
