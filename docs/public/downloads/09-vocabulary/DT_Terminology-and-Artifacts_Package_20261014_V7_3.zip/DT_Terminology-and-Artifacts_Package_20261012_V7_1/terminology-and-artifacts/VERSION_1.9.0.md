# Version 1.9.0 — TX7 flat packaging and correction groups (2026-10-05)

Updates only MAP TX7 Patient Change List, from profile version 0.1.0 to 0.2.0, and adds these version notes. Its id/canonical and all terminology codes are unchanged. All other V1_8 files are preserved byte for byte.

## Agreed packaging
The change List is the primary DE; the updated Patient is its required secondary DE. In FHIR metadata packaging both are native direct entries with corresponding DocumentReferences, in one outer Collection Bundle. The previous Patient is a direct supporting entry referenced by the SubmissionSet Source Patient Information mapping and Remove entries. No nested primary Bundle or additional Patient/Bundle profile is introduced. Both Patient roles remain for Add-only and Remove-only updates.

## Correction conventions
Entry ids are change-N-add and change-N-remove, with positive integer N. A shared N links a correction pair (one Remove and one Add); an unmatched group is standalone. Present Remove immediately before Add for readability. Validate and apply the pair together against the same logical field/occurrence. Element targeting continues to use the standard HL7 targetElement extension.

Added FHIRPath invariants require the id form, unique entry ids, action/id agreement, Add references matching List.subject, Remove references distinct from List.subject, and one previous Patient for Remove targets. Pair adjacency, same-field/occurrence matching, resource/element resolution and processing atomicity remain narrative rules requiring package/application checks; do not treat the differential as a complete update protocol.

## Remaining work
XD previous-Patient placement and cross-file reference resolution remain open. Source patient metadata extension definitions/dependencies and supporting Patient DE classification need completion. Load the R4-compatible HL7 targetElement definition when generating/validating the profile; do not import an R5 dependency as R4. Full HL7 Validator snapshot and invariant execution are outstanding.

## Validation performed
All JSON parsed; profile ids/cardinalities and terminology links checked; entry-id convention and action examples checked including rejected invalid forms. All baseline files except this profile preserved byte for byte. ZIP integrity verified. The earlier VERSION_1.8.0.md remains historical; this version supersedes its nested-Bundle wording.
